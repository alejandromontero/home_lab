<?php
$CONFIG = array (
  'htaccess.RewriteBase' => '/',
);
