<?php
$CONFIG = array (
  'upgrade.disable-web' => true,
);
