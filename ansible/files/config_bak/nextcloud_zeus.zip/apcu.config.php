<?php
$CONFIG = array (
  'memcache.local' => '\OC\Memcache\APCu',
);
